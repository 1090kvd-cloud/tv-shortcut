# TV App Manager (shortcut-generator)

Android TV (Leanback) app that:

1. Scans **every** installed package (`AppScanner`), not just apps with a
   Leanback banner — includes side-loaded phone apps that only expose a
   `MAIN`/`LAUNCHER` activity.
2. Shows them as a card grid (`AppGridFragment` + `AppCardPresenter`).
3. On click, generates a small standalone "redirector" APK carrying the
   target app's icon/label, signs it with a bundled **test** key, and
   hands it to the system installer via the `PackageInstaller` Session
   API (`ShortcutApkBuilder` → `ApkSigner` → `PackageInstallerHelper`).
   The OS's normal install confirmation dialog is what actually installs
   it — nothing here installs silently or touches other apps' data.

## Modules

- `:app` — the manager app itself.
- `:template-shortcut` — source of the generic "redirector" APK. Built
  once via `./gradlew :template-shortcut:copyTemplateApk`, which drops
  `shortcut-template.apk` into `app/src/main/assets/`. `ShortcutApkBuilder`
  copies that template per click and patches it.

## The one piece left as a stub: `ManifestPatcher`

Editing a binary `AndroidManifest.xml` / `resources.arsc` on-device (no
`aapt2`/NDK available at runtime) needs a dedicated library rather than
text substitution. `app/build.gradle.kts` already pulls in
[`io.github.reandroid:ARSCLib`](https://github.com/REAndroid/APKEditor),
a pure-JVM APK editor built for exactly this. `ShortcutApkBuilder.kt`
contains a `ManifestPatcher` class with the intended call shape
documented in its KDoc — wire it up against whichever ARSCLib version
you pin, since method names have moved between releases. Everything
around it (scanning, UI, signing, install flow) is complete and wired.

## Signing key

`ApkSigner` expects `app/src/main/assets/test-keystore.jks`. Generate a
real one locally (a placeholder README stands in its place in this
repo):

```bash
keytool -genkeypair -v -keystore test-keystore.jks -alias shortcut \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass android -keypass android \
  -dname "CN=TvAppRepo Test, OU=Dev, O=Example, L=NA, ST=NA, C=US"
```

Move the resulting file into `app/src/main/assets/`. This is a
**test-only** key checked into a repo — fine for side-loading your own
generated shortcuts, not for anything meant to be trusted elsewhere.

## Build order

```bash
./gradlew :template-shortcut:copyTemplateApk   # produces the template APK
./gradlew :app:assembleDebug                   # builds the manager app
```

## Permissions

- `QUERY_ALL_PACKAGES` — required on API 30+ to see apps without a
  shared signature/intent visibility to this app.
- `REQUEST_INSTALL_PACKAGES` — required to open a `PackageInstaller`
  session.

## Not implemented / left for you

- `ManifestPatcher` (see above).
- Icon replacement inside `resources.arsc` (also via ARSCLib, same file).
- Uninstall/cleanup flow for previously generated shortcuts.
- Handling apps with no exported launch activity gracefully in the UI
  (currently just filtered out by `AppScanner`).
