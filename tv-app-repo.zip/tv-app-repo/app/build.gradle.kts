plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.tvapprepo"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.tvapprepo"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // The prebuilt shortcut template APK is dropped into assets by the
    // :template-shortcut module's build (see buildSrc task copyTemplateApk).
    sourceSets["main"].assets.srcDirs("src/main/assets")
}

dependencies {
    implementation(project(":core-common"))
    implementation(project(":core-scan"))
    implementation(project(":core-install"))

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.leanback:leanback:1.0.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.fragment:fragment-ktx:1.8.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Pure-JVM APK/manifest patcher — edits binary AndroidManifest.xml,
    // resources.arsc and app icon without needing aapt2/NDK on-device.
    // https://github.com/REAndroid/APKEditor
    implementation("io.github.reandroid:ARSCLib:1.3.4")

    // Google's apksig — signs the patched APK (v1/v2/v3) with a bundled
    // debug/test keystore. Pure Java, works on-device.
    implementation("com.android.tools.build:apksig:8.5.0")
}
