package com.example.tvapprepo.ui

import android.view.ViewGroup
import androidx.leanback.widget.ImageCardView
import androidx.leanback.widget.Presenter
import com.example.tvapprepo.common.model.InstalledApp

private const val CARD_WIDTH_DP = 260
private const val CARD_HEIGHT_DP = 200

/**
 * Renders one [InstalledApp] as an ImageCardView. Leanback drives focus
 * scaling/elevation on this view automatically when it's a child of a
 * VerticalGridPresenter-managed grid — nothing extra needed here for
 * the focus visuals themselves.
 */
class AppCardPresenter : Presenter() {

    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val density = parent.resources.displayMetrics.density
        val cardView = ImageCardView(parent.context).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            setMainImageDimensions(
                (CARD_WIDTH_DP * density).toInt(),
                (CARD_HEIGHT_DP * density).toInt(),
            )
        }
        return ViewHolder(cardView)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, item: Any) {
        val app = item as InstalledApp
        val cardView = viewHolder.view as ImageCardView
        cardView.titleText = app.label
        cardView.contentText = when {
            app.isTvLauncherApp -> "TV app"
            app.isHiddenFromTvLauncher -> "Hidden — non-TV app"
            else -> "No launcher entry"
        }
        cardView.mainImage = app.icon
    }

    override fun onUnbindViewHolder(viewHolder: ViewHolder) {
        val cardView = viewHolder.view as ImageCardView
        cardView.badgeImage = null
        cardView.mainImage = null
    }
}
