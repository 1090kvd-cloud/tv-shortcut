package com.example.tvapprepo.ui

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.leanback.app.VerticalGridSupportFragment
import androidx.leanback.widget.ArrayObjectAdapter
import androidx.leanback.widget.OnItemViewClickedListener
import androidx.leanback.widget.Presenter
import androidx.leanback.widget.Row
import androidx.leanback.widget.RowPresenter
import androidx.leanback.widget.VerticalGridPresenter
import com.example.tvapprepo.common.contract.AppRepository
import com.example.tvapprepo.common.model.InstalledApp
import com.example.tvapprepo.common.model.ScanOptions
import com.example.tvapprepo.scan.AppScanner
import com.example.tvapprepo.ui.focus.DpadFocusHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

private const val NUM_COLUMNS = 5
private const val ZOOM_FACTOR = VerticalGridPresenter.ZOOM_FACTOR_MEDIUM

/**
 * Module 1's screen: a D-pad navigable grid of every installed app,
 * including ones with no TV launcher entry.
 *
 * This fragment depends only on [AppRepository] (core-common), not on
 * [AppScanner] directly — swap the one-liner in [appRepository] to
 * inject a fake for screenshot/UI tests.
 */
class AppGridFragment : VerticalGridSupportFragment() {

    private val adapter = ArrayObjectAdapter(AppCardPresenter())
    private val fragmentScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // Swap for DI (Hilt/manual) once the app has more than one module
    // wiring point; kept as a simple lazy for this module's scope.
    private val appRepository: AppRepository by lazy { AppScanner(requireContext()) }

    private var onAppSelected: ((InstalledApp) -> Unit)? = null
    private var onAppLongPressed: ((InstalledApp) -> Unit)? = null

    /** Called by MainActivity to wire Module 1's output into Module 3's input. */
    fun setAppSelectionListener(
        onSelected: (InstalledApp) -> Unit,
        onLongPressed: ((InstalledApp) -> Unit)? = null,
    ) {
        onAppSelected = onSelected
        onAppLongPressed = onLongPressed
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        title = "Installed Apps"

        gridPresenter = VerticalGridPresenter(ZOOM_FACTOR).apply {
            numberOfColumns = NUM_COLUMNS
        }
        this.adapter = this@AppGridFragment.adapter

        onItemViewClickedListener =
            OnItemViewClickedListener { _: Presenter.ViewHolder?, item: Any?, _: RowPresenter.ViewHolder?, _: Row? ->
                (item as? InstalledApp)?.let { onAppSelected?.invoke(it) }
            }

        // gridViewHolder becomes available only after the internal
        // VerticalGridView is created — this callback fires right after that.
        DpadFocusHelper(
            gridView = verticalGridView,
            onLongPress = { focusedView ->
                val position = verticalGridView.getChildAdapterPosition(focusedView)
                (adapter.get(position) as? InstalledApp)?.let { onAppLongPressed?.invoke(it) }
            },
        )

        loadApps()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        fragmentScope.cancel()
    }

    private fun loadApps(options: ScanOptions = ScanOptions()) {
        fragmentScope.launch {
            val apps = runCatching { appRepository.scan(options) }
                .getOrElse { error ->
                    Toast.makeText(requireContext(), "Scan failed: ${error.message}", Toast.LENGTH_LONG).show()
                    emptyList()
                }
            adapter.clear()
            adapter.addAll(0, apps)
        }
    }

    /** Exposed so MainActivity can wire a "show system apps" toggle if it adds one. */
    fun refresh(options: ScanOptions = ScanOptions()) {
        (appRepository as? AppScanner)?.invalidateCache()
        loadApps(options)
    }
}
