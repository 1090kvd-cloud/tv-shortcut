package com.example.tvapprepo.ui

import android.os.Bundle
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import com.example.tvapprepo.R
import com.example.tvapprepo.common.model.InstalledApp

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val gridFragment = supportFragmentManager
            .findFragmentById(R.id.main_browse_fragment) as? AppGridFragment
            ?: AppGridFragment().also {
                supportFragmentManager.beginTransaction()
                    .replace(R.id.main_browse_fragment, it)
                    .commitNow()
            }

        // Wiring into Modules 2-4 (build + install) lands here once those
        // modules are finalized; for now Module 1 is verifiable standalone.
        gridFragment.setAppSelectionListener(
            onSelected = { app -> onAppSelected(app) },
            onLongPressed = { app -> onAppLongPressed(app) },
        )
    }

    private fun onAppSelected(app: InstalledApp) {
        Toast.makeText(this, "Selected: ${app.label} (${app.packageName})", Toast.LENGTH_SHORT).show()
        // TODO: hand off to Module 3 (core-apkbuild) → ShortcutApkBuilder(app).build(...)
    }

    private fun onAppLongPressed(app: InstalledApp) {
        Toast.makeText(this, "Long-press: ${app.label}", Toast.LENGTH_SHORT).show()
        // TODO: context menu — e.g. "remove generated shortcut" for previously-built entries
    }
}
