package com.example.tvapprepo.ui.focus

import android.view.KeyEvent
import android.view.View
import androidx.leanback.widget.VerticalGridView

/**
 * Centralizes D-Pad specific behavior for the app grid so it isn't
 * scattered across the fragment:
 *
 *  - normalizes DPAD_CENTER / ENTER / NUMPAD_ENTER into one "confirm"
 *    callback, since remotes differ on which keycode they send for the
 *    center button;
 *  - pins focus so DPAD_UP from the first row and DPAD_DOWN from the
 *    last row don't let focus escape the grid onto nothing (which on
 *    some TV remotes/launchers manifests as focus just disappearing);
 *  - exposes a single place to wire long-press (context menu) without
 *    fighting Leanback's own click dispatch.
 */
class DpadFocusHelper(
    private val gridView: VerticalGridView,
    private val onConfirm: (View) -> Unit,
    private val onLongPress: ((View) -> Unit)? = null,
) {

    private var longPressTriggered = false

    init {
        // Keep the grid itself as a focus boundary: don't let BACK/UP/DOWN
        // move focus to a view outside this fragment by accident.
        gridView.descendantFocusability = VerticalGridView.FOCUS_AFTER_DESCENDANTS
        gridView.itemAnimator = null // avoid focus jumping mid-animation on fast D-pad repeats

        gridView.setOnKeyInterceptListener { event -> handleKeyEvent(event) }
    }

    private fun handleKeyEvent(event: KeyEvent): Boolean {
        val focused = gridView.focusedChild ?: return false

        return when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_NUMPAD_ENTER -> handleConfirmKey(event, focused)

            KeyEvent.KEYCODE_MENU -> handleLongPressKey(event, focused)

            else -> false
        }
    }

    private fun handleConfirmKey(event: KeyEvent, focused: View): Boolean {
        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount == 0) longPressTriggered = false
                if (event.repeatCount > LONG_PRESS_REPEAT_THRESHOLD && !longPressTriggered) {
                    longPressTriggered = true
                    onLongPress?.invoke(focused)
                }
            }
            KeyEvent.ACTION_UP -> {
                if (!longPressTriggered) onConfirm(focused)
                longPressTriggered = false
            }
        }
        // Consume it: we don't want the default Leanback click-on-KEYCODE_DPAD_CENTER
        // behavior AND ours both firing.
        return true
    }

    private fun handleLongPressKey(event: KeyEvent, focused: View): Boolean {
        if (event.action == KeyEvent.ACTION_UP) onLongPress?.invoke(focused)
        return onLongPress != null
    }

    companion object {
        private const val LONG_PRESS_REPEAT_THRESHOLD = 10
    }
}
