package com.example.tvapprepo.common.contract

import com.example.tvapprepo.common.model.InstalledApp
import com.example.tvapprepo.common.model.ScanOptions

/**
 * Contract for Module 1 (core-scan). The UI depends only on this
 * interface, never on AppScanner directly, so the scanning
 * implementation can be swapped/mocked independently.
 */
interface AppRepository {
    /**
     * Performs a full scan. This does real PackageManager work and
     * should be called off the main thread by the caller.
     */
    suspend fun scan(options: ScanOptions = ScanOptions()): List<InstalledApp>
}
