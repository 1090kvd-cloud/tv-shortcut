package com.example.tvapprepo.common.contract

import java.io.File

/**
 * Contract for Module 4 (core-install). The UI/orchestration layer
 * depends only on this — never on PackageInstallerHelper or
 * LegacyInstallIntent directly — so the API-level branching lives
 * entirely inside the implementation.
 */
interface Installer {
    /**
     * Hands [apkFile] to the system installer UI. This does NOT install
     * silently — the OS's own confirmation dialog is what performs the
     * install; [callback] just reports the outcome back.
     */
    fun install(apkFile: File, callback: InstallCallback)
}

interface InstallCallback {
    /** System install confirmation UI is about to be shown. */
    fun onUserConfirmationRequired()
    fun onSuccess()
    fun onFailure(reason: String)
}
