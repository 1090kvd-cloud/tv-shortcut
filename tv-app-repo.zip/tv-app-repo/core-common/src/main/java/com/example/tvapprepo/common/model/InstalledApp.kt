package com.example.tvapprepo.common.model

import android.graphics.drawable.Drawable

/**
 * Immutable snapshot of one installed package, produced by Module 1
 * (core-scan) and consumed by Module 3 (core-apkbuild). Nothing outside
 * core-scan should construct this directly — go through [com.example.tvapprepo.common.contract.AppRepository].
 */
data class InstalledApp(
    val packageName: String,
    val label: String,
    val icon: Drawable,
    val isSystemApp: Boolean,
    /** True if the package exposes a LEANBACK_LAUNCHER activity (a "real" TV app). */
    val isTvLauncherApp: Boolean,
    /** True if it exposes at least a standard LAUNCHER activity (phone app, side-loaded, etc.). */
    val hasStandardLauncherEntry: Boolean,
    val versionName: String?,
) {
    /** Convenience for UI badges — true when the app has no TV-specific entry point. */
    val isHiddenFromTvLauncher: Boolean
        get() = !isTvLauncherApp && hasStandardLauncherEntry
}
