package com.example.tvapprepo.common.model

/**
 * Filtering knobs exposed to the UI layer so a screen can, e.g., offer
 * a "show system apps" toggle without reaching into AppScanner internals.
 */
data class ScanOptions(
    val includeSystemApps: Boolean = false,
    /** When true, keep packages with NO launcher entry at all (rare — background-only apps). */
    val includeNonLaunchableApps: Boolean = false,
    val sortAlphabetically: Boolean = true,
)
