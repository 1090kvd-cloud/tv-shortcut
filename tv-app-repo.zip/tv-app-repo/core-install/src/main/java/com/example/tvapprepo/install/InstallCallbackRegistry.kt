package com.example.tvapprepo.install

import com.example.tvapprepo.common.contract.InstallCallback
import java.util.concurrent.ConcurrentHashMap

/**
 * [InstallResultReceiver] is instantiated by the system when the
 * broadcast fires, not by us — it has no constructor injection point
 * for the [InstallCallback] that kicked off a given install. This
 * process-lifetime registry bridges that gap, keyed by PackageInstaller
 * session id.
 *
 * Entries are removed once consumed; a callback that never gets a
 * matching broadcast (e.g. process died mid-install) is simply
 * garbage — acceptable here since a fresh install attempt after
 * process restart creates a new session id anyway.
 */
internal object InstallCallbackRegistry {

    private val callbacks = ConcurrentHashMap<Int, InstallCallback>()

    fun register(sessionId: Int, callback: InstallCallback) {
        callbacks[sessionId] = callback
    }

    /** Removes and returns the callback for [sessionId], if still present. */
    fun consume(sessionId: Int): InstallCallback? = callbacks.remove(sessionId)
}
