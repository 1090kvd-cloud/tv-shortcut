package com.example.tvapprepo.install

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller

/**
 * Registered in the manifest, fed by the PendingIntent that
 * [PackageInstallerSessionInstaller] passes to `session.commit(...)`.
 * The system broadcasts to this receiver with the session's outcome;
 * we look up the originating [com.example.tvapprepo.common.contract.InstallCallback]
 * via [InstallCallbackRegistry] using the session id carried in the
 * extras, since this receiver is instantiated fresh by the system and
 * has no other way to reach back to the caller.
 */
class InstallResultReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != PackageInstallerSessionInstaller.ACTION) return

        val sessionId = intent.getIntExtra(PackageInstallerSessionInstaller.EXTRA_SESSION_ID, -1)
        val callback = InstallCallbackRegistry.consume(sessionId)

        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)

        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                // Re-register: this isn't terminal yet, the confirmation
                // dialog forwarded below will eventually re-broadcast with
                // a terminal status once the user answers it.
                callback?.let { InstallCallbackRegistry.register(sessionId, it) }
                callback?.onUserConfirmationRequired()

                val confirmationIntent = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                confirmationIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                confirmationIntent?.let { context.startActivity(it) }
            }

            PackageInstaller.STATUS_SUCCESS -> {
                callback?.onSuccess()
            }

            else -> {
                val message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)
                    ?: "Install failed with status code $status"
                callback?.onFailure(message)
            }
        }
    }
}
