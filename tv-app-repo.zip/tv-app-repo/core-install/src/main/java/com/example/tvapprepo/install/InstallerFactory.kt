package com.example.tvapprepo.install

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import com.example.tvapprepo.common.contract.InstallCallback
import com.example.tvapprepo.common.contract.Installer
import java.io.File

/**
 * The single entry point Module 3 (or the UI layer) should depend on —
 * via the [Installer] contract, never on this class directly. Picks the
 * concrete strategy by API level:
 *
 *   API 24+  → [PackageInstallerSessionInstaller] (Session API)
 *   API < 24 → [LegacyInstallIntentInstaller] (ACTION_INSTALL_PACKAGE + FileProvider)
 *
 * On API 26+, "install unknown apps" is a per-app special permission
 * the user grants in Settings, not a manifest-time grant — [install]
 * checks [hasInstallPermission] first and fails fast with a clear
 * reason rather than silently no-oping when it's missing, so the UI
 * layer can route the user to [permissionSettingsIntent].
 */
class InstallerFactory(context: Context) : Installer {

    private val appContext = context.applicationContext

    override fun install(apkFile: File, callback: InstallCallback) {
        if (!apkFile.exists() || apkFile.length() == 0L) {
            callback.onFailure("APK file missing or empty: ${apkFile.path}")
            return
        }

        if (!hasInstallPermission(appContext)) {
            callback.onFailure(
                "REQUEST_INSTALL_PACKAGES not granted for this app — " +
                    "send the user to permissionSettingsIntent() first."
            )
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            PackageInstallerSessionInstaller(appContext).install(apkFile, callback)
        } else {
            LegacyInstallIntentInstaller(appContext).install(apkFile, callback)
        }
    }

    companion object {

        /**
         * API 26+: "install unknown apps" is a per-source-app toggle the
         * user sets in Settings, queried via canRequestPackageInstalls().
         * API 21-25: governed purely by the manifest-declared
         * REQUEST_INSTALL_PACKAGES permission, which is granted at
         * install time — nothing to check at runtime.
         */
        fun hasInstallPermission(context: Context): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.packageManager.canRequestPackageInstalls()
            } else {
                true
            }
        }

        /**
         * Deep-links into the system settings screen where the user
         * grants "install unknown apps" for this app specifically.
         * Only meaningful on API 26+ — callers should gate on
         * [hasInstallPermission] returning false before using this.
         */
        fun permissionSettingsIntent(context: Context): Intent {
            return Intent(
                android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}"),
            )
        }
    }
}
