package com.example.tvapprepo.install

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.tvapprepo.common.contract.InstallCallback
import java.io.File

/**
 * Fallback install path for API 21-23, where [android.content.pm.PackageInstaller.Session]
 * either doesn't exist (API < 24) or has been historically flaky on
 * some older TV OEM firmware. Uses the classic
 * [Intent.ACTION_INSTALL_PACKAGE] with a `content://` URI.
 *
 * A raw `file://` URI is deliberately never used here: since API 24 the
 * platform enforces FileExposedException for file:// Uris crossing the
 * app boundary via Intent, and even below that, FileProvider is the
 * only way to grant the installer package temporary, scoped read
 * access to a single file instead of exposing the whole cache dir.
 *
 * The authority (`<applicationId>.fileprovider`) and the exposed path
 * (`shortcut-build/`) MUST match:
 *   - core-install/src/main/AndroidManifest.xml  (provider declaration)
 *   - core-install/src/main/res/xml/tvapprepo_file_paths.xml
 *   - Module 3's ShortcutApkBuilder workDir
 */
internal class LegacyInstallIntentInstaller(private val context: Context) {

    fun install(apkFile: File, callback: InstallCallback) {
        val apkUri = runCatching { buildContentUri(apkFile) }
            .getOrElse {
                callback.onFailure("FileProvider could not resolve a URI for ${apkFile.name}: ${it.message}")
                return
            }

        val installIntent = Intent(Intent.ACTION_INSTALL_PACKAGE).apply {
            setDataAndType(apkUri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(Intent.EXTRA_NOT_UNKNOWN_SOURCE, true)
            putExtra(Intent.EXTRA_RETURN_RESULT, true)
        }

        val resolvedActivity = installIntent.resolveActivity(context.packageManager)
        if (resolvedActivity == null) {
            callback.onFailure("No system component can handle ACTION_INSTALL_PACKAGE on this device")
            return
        }

        callback.onUserConfirmationRequired()
        context.startActivity(installIntent)

        // Unlike the Session API, this path has no reliable programmatic
        // success/failure signal without also using startActivityForResult
        // from an Activity context (not available from a plain Context
        // here) — see README note in InstallerFactory.kt. We report the
        // hand-off as the terminal event for this path.
        callback.onSuccess()
    }

    private fun buildContentUri(apkFile: File): Uri {
        val authority = "${context.packageName}.fileprovider"
        return FileProvider.getUriForFile(context, authority, apkFile)
    }
}
