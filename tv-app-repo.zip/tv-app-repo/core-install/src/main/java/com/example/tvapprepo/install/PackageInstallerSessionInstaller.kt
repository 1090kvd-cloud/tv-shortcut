package com.example.tvapprepo.install

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import com.example.tvapprepo.common.contract.InstallCallback
import java.io.File

private const val SESSION_ACTION = "com.example.tvapprepo.install.ACTION_SESSION_RESULT"

/**
 * Installs via [PackageInstaller.Session] — the modern, recommended
 * path (API 24+). No FileProvider/content:// URI involved: the APK
 * bytes go straight into the session's own [PackageInstaller.Session.openWrite]
 * stream, which the system already trusts by construction.
 *
 * Requires [android.Manifest.permission.REQUEST_INSTALL_PACKAGES] to be
 * granted — on API 26+ this is requested like a normal runtime
 * permission via Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES if not
 * already granted; this class assumes the caller has already verified
 * that (see [hasInstallPermission]) before calling [install].
 */
internal class PackageInstallerSessionInstaller(private val context: Context) {

    fun install(apkFile: File, callback: InstallCallback) {
        require(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            "PackageInstaller.Session requires API 24+; caller should route to the legacy path below that."
        }

        val packageInstaller = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
            setAppPackageName(null) // unknown until the manifest inside apkFile is parsed by the system
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                setInstallReason(android.content.pm.PackageManager.INSTALL_REASON_USER)
            }
        }

        val sessionId = runCatching { packageInstaller.createSession(params) }
            .getOrElse {
                callback.onFailure("Could not create install session: ${it.message}")
                return
            }

        val session = runCatching { packageInstaller.openSession(sessionId) }
            .getOrElse {
                callback.onFailure("Could not open install session: ${it.message}")
                return
            }

        InstallCallbackRegistry.register(sessionId, callback)

        session.use { openSession ->
            val writeResult = runCatching {
                apkFile.inputStream().use { input ->
                    openSession.openWrite(apkFile.name, 0, apkFile.length()).use { out ->
                        input.copyTo(out)
                        openSession.fsync(out)
                    }
                }
            }

            if (writeResult.isFailure) {
                InstallCallbackRegistry.consume(sessionId)
                callback.onFailure("Failed writing APK into session: ${writeResult.exceptionOrNull()?.message}")
                openSession.abandon()
                return
            }

            val pendingIntent = buildResultPendingIntent(sessionId)
            openSession.commit(pendingIntent.intentSender)
            // From here on, InstallResultReceiver (fed by SESSION_ACTION)
            // owns the rest of the flow via InstallCallbackRegistry.
        }
    }

    private fun buildResultPendingIntent(sessionId: Int): PendingIntent {
        val intent = Intent(SESSION_ACTION)
            .setPackage(context.packageName)
            .putExtra(EXTRA_SESSION_ID, sessionId)

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0

        return PendingIntent.getBroadcast(context, sessionId, intent, flags)
    }

    companion object {
        const val EXTRA_SESSION_ID = "com.example.tvapprepo.install.EXTRA_SESSION_ID"
        const val ACTION = SESSION_ACTION
    }
}
