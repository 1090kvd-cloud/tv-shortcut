package com.example.tvapprepo.scan

import com.example.tvapprepo.common.model.InstalledApp
import com.example.tvapprepo.common.model.ScanOptions
import java.util.concurrent.atomic.AtomicReference

/**
 * Process-lifetime cache of the last scan result, keyed by the
 * [ScanOptions] that produced it. Scanning every installed package
 * (icon loading especially) is not free — a config change or fragment
 * recreation shouldn't force a full re-scan.
 *
 * Not persisted across process death by design: package state can
 * change between app launches (installs/uninstalls), so a cold start
 * always re-scans.
 */
internal class AppScanCache {

    private data class Entry(val options: ScanOptions, val apps: List<InstalledApp>)

    private val cached = AtomicReference<Entry?>(null)

    fun get(options: ScanOptions): List<InstalledApp>? {
        val entry = cached.get() ?: return null
        return entry.apps.takeIf { entry.options == options }
    }

    fun put(options: ScanOptions, apps: List<InstalledApp>) {
        cached.set(Entry(options, apps))
    }

    fun invalidate() {
        cached.set(null)
    }
}
