package com.example.tvapprepo.scan

import android.content.pm.ApplicationInfo
import com.example.tvapprepo.common.model.ScanOptions

/**
 * Pure (no Android framework calls beyond the ApplicationInfo flags
 * already resolved) filtering rules, kept separate from [AppScanner] so
 * the decision logic can be unit-tested with plain JVM tests instead of
 * an instrumented/Robolectric PackageManager.
 */
internal class AppScanFilter(private val options: ScanOptions) {

    /**
     * @param packageName the package under evaluation
     * @param appInfo its ApplicationInfo (for the system-app flag)
     * @param isLeanbackLaunchable true if it has a LEANBACK_LAUNCHER activity
     * @param isStandardLaunchable true if it has a standard LAUNCHER activity
     */
    fun shouldInclude(
        appInfo: ApplicationInfo,
        isLeanbackLaunchable: Boolean,
        isStandardLaunchable: Boolean,
    ): Boolean {
        val isSystem = appInfo.flags and ApplicationInfo.FLAG_SYSTEM != 0
        val hasAnyEntryPoint = isLeanbackLaunchable || isStandardLaunchable

        if (isSystem && !options.includeSystemApps) return false
        if (!hasAnyEntryPoint && !options.includeNonLaunchableApps) return false

        return true
    }
}
