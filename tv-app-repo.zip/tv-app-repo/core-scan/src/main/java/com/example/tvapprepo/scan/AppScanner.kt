package com.example.tvapprepo.scan

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.example.tvapprepo.common.contract.AppRepository
import com.example.tvapprepo.common.model.InstalledApp
import com.example.tvapprepo.common.model.ScanOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Module 1's core: scans every installed package, including apps that
 * expose no Leanback banner (side-loaded phone apps, hidden system
 * utilities with a launchable Activity, etc.).
 *
 * Two independent CATEGORY_LAUNCHER-style queries decide whether a
 * package has an entry point at all, and which kind:
 *
 *  - CATEGORY_LEANBACK_LAUNCHER → shows up on the normal TV home screen
 *  - CATEGORY_LAUNCHER          → standard "app drawer" entry point
 *    (present on Android TV too, just not surfaced on the home screen
 *    unless the OEM launcher chooses to show it)
 *
 * A package can have neither (library/service-only), either, or both.
 */
class AppScanner(context: Context) : AppRepository {

    private val appContext = context.applicationContext
    private val pm: PackageManager = appContext.packageManager
    private val cache = AppScanCache()

    override suspend fun scan(options: ScanOptions): List<InstalledApp> {
        cache.get(options)?.let { return it }

        val result = withContext(Dispatchers.IO) { performScan(options) }
        cache.put(options, result)
        return result
    }

    /** Call after an install/uninstall you know about, to force a fresh scan next time. */
    fun invalidateCache() = cache.invalidate()

    private fun performScan(options: ScanOptions): List<InstalledApp> {
        val leanbackLaunchable = queryLaunchablePackages(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val standardLaunchable = queryLaunchablePackages(Intent.CATEGORY_LAUNCHER)
        val filter = AppScanFilter(options)

        // getInstalledApplications gives us the full universe of packages
        // (including ones with zero launcher entry points, needed for the
        // includeNonLaunchableApps=true case); the two queries above tell
        // us WHICH kind of entry point each one has, if any.
        val allApplicationInfos = pm.getInstalledApplications(PackageManager.GET_META_DATA)

        val apps = allApplicationInfos.mapNotNull { appInfo ->
            val isLeanback = appInfo.packageName in leanbackLaunchable
            val isStandard = appInfo.packageName in standardLaunchable

            if (!filter.shouldInclude(appInfo, isLeanback, isStandard)) return@mapNotNull null

            appInfo.toInstalledApp(isLeanback, isStandard)
        }

        return if (options.sortAlphabetically) {
            apps.sortedBy { it.label.lowercase() }
        } else {
            apps
        }
    }

    /**
     * Resolves every activity that answers ACTION_MAIN + [category], and
     * returns the distinct set of owning package names.
     *
     * MATCH_ALL is used (rather than the default) so we also catch
     * activities disabled via PackageManager.setComponentEnabledSetting
     * or gated behind a manifest <intent-filter> the OEM launcher itself
     * ignores — we want to know the entry point exists at all.
     */
    private fun queryLaunchablePackages(category: String): Set<String> {
        val queryIntent = Intent(Intent.ACTION_MAIN).addCategory(category)
        val resolveInfos = pm.queryIntentActivities(queryIntent, PackageManager.MATCH_ALL)
        return resolveInfos.mapTo(mutableSetOf()) { it.activityInfo.packageName }
    }

    private fun ApplicationInfo.toInstalledApp(
        isLeanbackLaunchable: Boolean,
        isStandardLaunchable: Boolean,
    ): InstalledApp {
        val versionName = runCatching {
            pm.getPackageInfo(packageName, 0).versionName
        }.getOrNull()

        return InstalledApp(
            packageName = packageName,
            label = pm.getApplicationLabel(this).toString(),
            icon = pm.getApplicationIcon(this),
            isSystemApp = flags and ApplicationInfo.FLAG_SYSTEM != 0,
            isTvLauncherApp = isLeanbackLaunchable,
            hasStandardLauncherEntry = isStandardLaunchable,
            versionName = versionName,
        )
    }
}
