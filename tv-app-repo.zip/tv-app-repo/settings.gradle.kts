pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "TvAppRepo"
include(":app")
include(":template-shortcut")
include(":core-common")
include(":core-scan")
include(":core-install")
