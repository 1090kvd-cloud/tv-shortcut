plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.shortcut"
    compileSdk = 34

    defaultConfig {
        // Overwritten per-instance by ShortcutApkBuilder at patch time.
        applicationId = "com.example.shortcut"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}

// Copies the assembled unsigned APK from this module into :app's assets
// under the fixed name shortcut-template.apk, so ShortcutApkBuilder can
// find and patch a fresh copy per generated shortcut.
tasks.register<Copy>("copyTemplateApk") {
    dependsOn("assembleDebug")
    from(layout.buildDirectory.file("outputs/apk/debug/template-shortcut-debug.apk"))
    into(project(":app").file("src/main/assets"))
    rename { "shortcut-template.apk" }
}
