package com.example.shortcut

import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

private const val META_KEY = "com.example.shortcut.TARGET_PACKAGE"

/**
 * Invisible entry point. Reads the target package name that
 * ShortcutApkBuilder wrote into this activity's <meta-data> at patch
 * time, resolves its launch intent, starts it, and finishes itself —
 * this activity never stays on the back stack.
 */
class RedirectActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val targetPackage = readTargetPackage()
        val launchIntent = targetPackage?.let { packageManager.getLaunchIntentForPackage(it) }

        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "Target app not found (was it uninstalled?)", Toast.LENGTH_LONG).show()
        }
        finish()
    }

    private fun readTargetPackage(): String? {
        val info = packageManager.getActivityInfo(componentName, PackageManager.GET_META_DATA)
        return info.metaData?.getString(META_KEY)
    }
}
